#include<pthread.h>
#include<unistd.h>
#include<sys/types.h>
#include<linux/fcntl.h>
#include<stdlib.h>
#include<stdio.h>


pthread_attr_t at1,at2,at3;

struct handle{

int param1;
int param2;
int param3;
};


void *method1(void *arg)
{

	struct handle *fd= (struct handle *)arg;
	int ret;
	int buf[1024];

 printf("Thread of fd is FdBar=%d,Baz=%d,Foo=%d\n", fd->param1,fd->param2,fd->param3); 

 // readin param1
lseek(fd->param1,0,SEEK_SET);
 ret = read(fd->param1,buf,30);
 printf("the no. characters returned is %d\n", ret);
if(ret>0) { write(STDOUT_FILENO,buf,ret); }
if(ret==0) printf("error in read\n");

// readin param2
lseek(fd->param2,0,SEEK_SET);
 ret = read(fd->param2,buf,30);
 printf("the no. characters returned is %d\n", ret);
if(ret>0) { write(STDOUT_FILENO,buf,ret); }

// readin param3

lseek(fd->param3,0,SEEK_SET);
 ret = read(fd->param3,buf,30);
 printf("the no. characters returned is %d\n", ret);
if(ret>0) { write(STDOUT_FILENO,buf,ret); }

pthread_exit(NULL);


}




int main()
{
	
   pthread_t thread1,thread2,thread3;
  
   struct handle fd0,fd1,fd2;
   struct handle *dev1=&fd0;
   struct handle *dev2=&fd1;
   struct handle *dev3=&fd2;

	

  int fdBar,fdBaz,fdFoo,ret,buf[1024];
   int ret1;
   //this will setup an active file, for the process - ??
   //this active file will be different from a regular
   //active file of a regular file !!
   
   //this handle to an active file is used to 
   //access the actual system data exported 
   //by the procfs file/kernel module 
   
   //printf("Parent PID %d \n",getpid());
   

  

   dev1->param1  = open("/sys/kernel/kset_devices_typeA/device0/dev_param1",O_RDWR);
   dev1->param2  = open("/sys/kernel/kset_devices_typeA/device0/dev_param2",O_RDWR);
   dev1->param3  = open("/sys/kernel/kset_devices_typeA/device0/dev_param3",O_RDWR);
 
   dev2->param1  = open("/sys/kernel/kset_devices_typeA/device1/dev_param1",O_RDWR);
   dev2->param2  = open("/sys/kernel/kset_devices_typeA/device1/dev_param2",O_RDWR);
   dev2->param3  = open("/sys/kernel/kset_devices_typeA/device1/dev_param3",O_RDWR);
   
   dev3->param1  = open("/sys/kernel/kset_devices_typeA/device2/dev_param1",O_RDWR);
   dev3->param2  = open("/sys/kernel/kset_devices_typeA/device2/dev_param2",O_RDWR);
   dev3->param3  = open("/sys/kernel/kset_devices_typeA/device2/dev_param3",O_RDWR);

   if(dev1->param1 < 0 && dev1->param2 < 0 && dev1->param3 < 0 ){
           perror("error in opening dev1 ");
           exit(1);
   }

   if(dev2->param1 < 0 && dev2->param2 < 0 && dev2->param3 < 0 ){
           perror("error in opening dev2");
           exit(1);
   }

   if(dev3->param1 < 0 && dev3->param2 < 0 && dev3->param3 < 0 ){
           perror("error in opening dev3");
           exit(1);
   }

   ret1=pthread_create(&thread1,NULL,method1,(void *)dev1);
if(ret1!=0){
         perror("error in creating Thread1");
	   exit(1);
}


 ret1=  pthread_create(&thread2,NULL,method1,(void *)dev2);

if(ret1!=0){
           perror("error in creating Thread2");
	   exit(1);
}

   
ret1 = pthread_create(&thread3,NULL,method1,(void *)dev3);

if(ret1!=0){
           perror("error in creating Thread3");
	   exit(1);
}



 printf("value of fd is FdBar=%d,Baz=%d,Foo=%d\n", dev1->param1,dev1->param2,dev1->param3); 


  // exit(0); //just for testing open() 
 /*  lseek(fd,22,SEEK_SET);*/

/*  ret = read(fd,buf,30);
  printf("1..the no. characters returned is %d\n", ret);

  if(ret>0) { write(STDOUT_FILENO,buf,ret); }*/


 /* ret = read(fd,buf,13);
  printf("1..the no. characters returned is %d\n", ret);

  if(ret>0) { write(STDOUT_FILENO,buf,ret); }
*/


  /*ret = read(fd,buf,15);
   printf("2..the no. characters returned is %d\n", ret);
   

  if(ret>0) { write(STDOUT_FILENO,buf,ret); } */

  // ret = read(fd,buf,4096);*/
  // printf("1..the no. characters returned is %d\n", ret);

  //if(ret>0) { write(STDOUT_FILENO,buf,ret); }

  /* ret = read(fd,buf,2048);
   printf("1..the no. characters returned is %d\n", ret);

  if(ret>0) { write(STDOUT_FILENO,buf,ret); }
   ret = read(fd,buf,15);
   printf("the no. characters returned is %d\n", ret);

   if(ret>0) { write(STDOUT_FILENO,buf,ret); }*/
  
 //read() system call API returns +ve value, 
 //if there are bytes read into the user-space
 //buffer - if we pass a value to p3, read may 
 //copy lesser number of bytes and return a 
 //different size value, in ret - we must check 
 //this value, before further processing
 //
 //in addition, you may need to check for 
 //return value of 0, if there are no bytes
 //read() by the read() system call API- 
 //this normally happens, if there is no 
 //more data, in the active file, which can 
 //be a normal file or a procfs file 
 //
 //we may see a return value of -1, if there
 //is error, in access of the active - in the 
 //case of invalid fd or invalid access permissions 
 //
//Writing Dummy Data
/*	ret =  write(fdFoo,"11",4);
  	if(ret<0){
		printf("ERROR In write %d \n",ret);
	 }
 	printf("No of bytes written %d \n",ret);*/
/*
	ret =  write(fdBaz,"hello",6);
  	if(ret<0){
		printf("ERROR In write %d \n",ret);
	 }
 	printf("No of bytes written %d \n",ret);
	
	ret =  write(fdBar,"a",1);
  	if(ret<0){
		printf("ERROR In write %d \n",ret);
	 }
 	printf("No of bytes written %d \n",ret);

*/
/*
 fd = open("/sys/kernel/kobject_example/foo",O_RDONLY);*/
/*  
 lseek(fdFoo,0,SEEK_SET);
   ret = read(fdFoo,buf,1024);
   printf("No of bytes read %d\n",ret);
   if(ret<0) { perror("error in read"); exit(6); }
  
   if(ret>0) {
	  printf("Foo\n"); 
	   write(STDOUT_FILENO,buf,ret); }
  					*/
  /* lseek(fdBaz,0,SEEK_SET);
   ret = read(fdBaz,buf,1024);
   printf("No of bytes read %d\n",ret);
   if(ret<0) { perror("error in read"); exit(6); }
   if(ret>0) { 
	  printf("Baz\n"); 
	   write(STDOUT_FILENO,buf,ret); } 
  
   lseek(fdBar,0,SEEK_SET);
   ret = read(fdBar,buf,1024);
   printf("No of bytes read %d\n",ret);
   if(ret<0) { perror("error in read"); exit(6); }
   if(ret>0) { 
	  printf("Bar\n"); 
	   write(STDOUT_FILENO,buf,ret); } 
*/
 // close(fdFoo);
 // close(fdBaz);
 // close(fdBar);
  pthread_join(thread1,NULL);
  pthread_join(thread2,NULL);
  pthread_join(thread3,NULL);
  // close(fdFoo);
  // close(fdBaz);
  // close(fdBar);

     	exit(0);

}
