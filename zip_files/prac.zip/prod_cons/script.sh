#!/bin/bash
ipcrm -a
gcc -o p prod.c
./p
