/* Producer Code*/

/*before running check weather IPC key Is available
 * run code in previlege MOde*/

#include<stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/sem.h>
#include<string.h>


#define IPCKEY 1000      // Check key before assign weather it is avialiable or not
#define NoSEMA 3

struct shareMem{		// Structure for shared Memory

	int index1;
	int index2;
	char *buf[1024];
	 char str[50][1024];
};

/* Union Is needed for Semaphore Control Operations*/
union semun {
               int              val;    /* Value for SETVAL */
               struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
               unsigned short  *array;  /* Array for GETALL, SETALL */
               struct seminfo  *__buf;  /* Buffer for IPC_INFO
                                           (Linux-specific) */
           };


union semun u1;
struct sembuf semobj2,semobj1,semobj0;       // Semaphore Object Which will be handling semaphores

void main(int argc, char* argv[])
{

	
	char buffer[1024];
	struct shareMem *ptr=NULL;		// Pointer to shared Memoery
	
/*---------- Semaphore Init--------------*/

  int id2=semget(IPCKEY,NoSEMA,IPC_CREAT|0666);	// Creating Semanphores  
						// P1= IPC Key
						// P2= Number of semaphores to be 
						// created
						// P3= Flags
						// If sucessful returns 
						// semaphore identifier	

	if(id2==-1)
	{
		printf("Error in SEMGET");
		exit(1);
	
	}

unsigned short int array[3]={50,0,1};
	u1.array=array;			// Initial Values of semaphore
int ret_sem=semctl(id2,0,SETALL,u1);	// semaphore control operation
					// P1=ID of semaphore
					// P2=This value is ignored
					// according to flag set of P3
					// P3= Flag to do control Operation
					//P4= u1>> setting initial value u1.array
					//on sucess and for SETALL flag returns 0
	
	if(ret_sem!=0)
	{
		printf("SemCtl Unsucessful\n");
	}
	ret_sem=semctl(id2,0,GETVAL);
	printf("Semaphore.0 inital value=%d\n",ret_sem);

	ret_sem=semctl(id2,1,GETVAL);
	printf("Semaphore.1 inital value=%d\n",ret_sem);

	ret_sem=semctl(id2,2,GETVAL);
	printf("Semaphore.2 inital value=%d\n",ret_sem);
/*----------------------------*/	
/*Shared Memory Section*/

int id=shmget(IPCKEY,4*4096,IPC_CREAT|0666);	// Assign shared Memory segments
						//P1= IPCKEY
					       //P2=sizeof shared Mem want to Assign
						//P3= Flag for shared memory
						//and prevelige setting	
						// returns ID of shared segment to 
						// get pointer to shared memory use
						// >>shmat<< 
						// for control >>shmctl()<<
if(id==-1)
{
	printf("ERROR In SHMGET\n");
}

ptr=shmat(id,0,0);		// Shared Memory Pointer return
				//P1= ID for Shared Segment
				//P2= to give address for shared mem
				//if null,system will provide its own
				//address
				//P3 = Flags choose as per required
if(ptr==NULL)
{
	printf("Error in SHMCTL\n");
}


/*
 * taking semobj[0]=free resource
 * 	  semobj[1]=filled resource
 * 	  semobj[2]=binary lock
 * 	  */

	while(1)
	{


			
/* check filled slot available or not*/			

			semobj1.sem_num = 1;        /* Operate on semaphore 1 */
	                semobj1.sem_op = -1;         /* Decrement value by one */
                        semobj1.sem_flg = 0;
			semop(id2,&semobj1,1);   // it will decrement free slot
					       // if not avialable it will block
/* put binary lock to do write operations*/ 		
			printf("check1\n");
		       	semobj2.sem_num = 2;        /* Operate on semaphore 2 */
                        semobj2.sem_op = -1;         /* Decrement value by one */
                        semobj2.sem_flg = 0;
                        semop(id2,&semobj2,1);   // if resource avialiable to write 
					       // then lock 

			
                strcpy(buffer,ptr->str[ptr->index1-1]);
					
		printf("Mes=%s",buffer);	
                       
	       	printf("Index=%d\n",ptr->index1);     
			
	       	ptr->index1--; 
				
			//Unlocking after operations
                      
		      	semobj2.sem_num = 2;        /* Operate on semaphore 2 */
                        semobj2.sem_op = 1;         /* Increment value by one */
                        semobj2.sem_flg = 0;
                        semop(id2,&semobj2,1);
	/*Unlock binary lock first
	 * then increment filled resource count
	 * and decrement free resources*/

		      	semobj0.sem_num = 0;        /* Operate on semaphore 0 */
                        semobj0.sem_op = 1;         /* Increment value by one */
                        semobj0.sem_flg = 0;	      // Free resources
                        semop(id2,&semobj0,1);
		
	}
	


}
