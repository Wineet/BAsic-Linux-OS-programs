

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/platform_device.h>
#include <linux/gpio.h>
#include <linux/leds.h>
#include <linux/of_platform.h>
#include <linux/of_gpio.h>
#include <linux/slab.h>
#include <linux/workqueue.h>
#include <linux/module.h>
#include <linux/pinctrl/consumer.h>
#include <linux/err.h>




struct led_obj {
        struct kobject kobj;
        int led;
};


static struct kobject *led1_kobj;
static struct kobject *led2_kobj;
static struct kobject *led3_kobj;


unsigned int out_gpio1 = 0, out_gpio2 = 0, out_gpio3 = 0;


static ssize_t led_show(struct kobject *kobj, struct kobj_attribute *attr,
                        char *buf)
{
	int var;

        dump_stack();

        if (strcmp(attr->attr.name, "led1") == 0){
		
		var = gpio_get_value(out_gpio1);
                
        }
        else if (strcmp(attr->attr.name, "led2") == 0){
                var = gpio_get_value(out_gpio2);
        }
        else {
               	var = gpio_get_value(out_gpio3);
        }

        return sprintf(buf, "%d\n", var);
}

static ssize_t led_store(struct kobject *kobj, struct kobj_attribute *attr,
                       const char *buf, size_t count)
{
        int var;

        sscanf(buf, "%du", &var);
        if (strcmp(attr->attr.name, "led1") == 0){
		gpio_set_value(out_gpio1, var);
	}	
        else if (strcmp(attr->attr.name, "led2") == 0){
		gpio_set_value(out_gpio2, var);
	}
        else {
		gpio_set_value(out_gpio3, var);
	}
        return count;
}

static struct kobj_attribute led1_attribute =
        __ATTR(led1, 0666, led_show, led_store);
//static struct kobj_attribute led1_attribute =
//        __ATTR(led1, 0222, NULL, led_store);
static struct kobj_attribute led2_attribute =
        __ATTR(led2, 0666, led_show, led_store);
static struct kobj_attribute led3_attribute =
        __ATTR(led3, 0666, led_show, led_store);

static struct attribute *attrs[] = {
        &led1_attribute.attr,
        &led2_attribute.attr,
        &led3_attribute.attr,
        NULL,   /* need to NULL terminate the list of attributes */
};

static struct attribute_group attr_group = {
        .attrs = attrs,
};

static int gpio_led_probe(struct platform_device *pdev)
{
      	struct pinctrl *pinctrl;  
	struct device_node *np, *child=NULL;
	unsigned int index=0;
	unsigned int count=0;
	int ret, retval;
	

	struct kobject *p_kobj = &pdev->dev.kobj;



	np = pdev->dev.of_node; 

	printk("My driver probe Enter: gpio-control-leds");
	dump_stack();
	printk("My driver probe Exit: gpio-control-leds");

        pinctrl = devm_pinctrl_get_select_default(&pdev->dev);
        if (IS_ERR(pinctrl))
        	dev_warn(&pdev->dev,"pins are not configured from the driver\n");

       	count = of_get_child_count(np);
        if (!count)
       		return ERR_PTR(-ENODEV);


	for_each_child_of_node(np, child)
	{
				

		if(index == 0)
			out_gpio1 = of_get_gpio(child, 0);
		else if(index == 1)
		 	out_gpio2 = of_get_gpio(child, 0);
		else if(index == 2)
		  	out_gpio3 = of_get_gpio(child, 0);
		index++;

	}
	
	printk("our gpios = %d %d %d\n", out_gpio1, out_gpio2, out_gpio3);

	ret = gpio_request(out_gpio1, "led1");
      if (ret) {
                dev_err(&pdev->dev, "unable to request gpio %d\n", out_gpio1);
//                goto error_gpio_request;
        }

	ret = gpio_request(out_gpio2, "led2");
      if (ret) {
                dev_err(&pdev->dev, "unable to request gpio %d\n", out_gpio2);
         //       goto error_gpio_request;
        }

	ret = gpio_request(out_gpio3, "led3");
      if (ret) {
                dev_err(&pdev->dev, "unable to request gpio %d\n", out_gpio3);
       //         goto error_gpio_request;
        }
     

	gpio_direction_output(out_gpio1, 1);
        gpio_direction_output(out_gpio2, 1);
        gpio_direction_output(out_gpio3, 1);

	led1_kobj = kobject_create_and_add("led1", p_kobj);
        if (!led1_kobj)
                return -ENOMEM;

	led2_kobj = kobject_create_and_add("led2", p_kobj);
        if (!led2_kobj)
                return -ENOMEM;
	
	led3_kobj = kobject_create_and_add("led3", p_kobj);
        if (!led3_kobj)
                return -ENOMEM;

        retval = sysfs_create_file(led1_kobj, &led1_attribute.attr);
        if (retval)
                kobject_put(led1_kobj);
        
	retval = sysfs_create_file(led2_kobj, &led2_attribute.attr);
        if (retval)
                kobject_put(led2_kobj);
        
	retval = sysfs_create_file(led3_kobj, &led3_attribute.attr);
        if (retval)
                kobject_put(led3_kobj);

/*        retval = sysfs_create_group(led1_kobj, &attr_group);
        if (retval)
                kobject_put(led1_kobj);

        retval = sysfs_create_group(led2_kobj, &attr_group);
        if (retval)
                kobject_put(led2_kobj);
        
	retval = sysfs_create_group(led3_kobj, &attr_group);
        if (retval)
                kobject_put(led3_kobj);
  */      
/*	
	gpio = devm_gpio_request(&dev, out_gpio1, "led1");
	if(gpio) {
		printk("could not request gpio for led1");
	}

	gpio = devm_gpio_request(&dev, out_gpio2, "led2");
	if(gpio) {
		printk("could not request gpio for led2");
	}

	gpio = devm_gpio_request(&dev, out_gpio3, "led3");
	if(gpio) {
		printk("could not request gpio for led3");
	}

	for_each_child_of_node(np, child) {
                struct gpio_led led = {};
		const char *state;

		led.gpio = of_get_gpio_flags(child, 0, &flags);
		led.name = of_get_property(child, "label", NULL) ? : child->name;
                state = of_get_property(child, "default-state", NULL);
                if (state) {
                        if (!strcmp(state, "keep"))
                                led.default_state = LEDS_GPIO_DEFSTATE_KEEP;
                        else if (!strcmp(state, "on"))
                                led.default_state = LEDS_GPIO_DEFSTATE_ON;
                        else
                                led.default_state = LEDS_GPIO_DEFSTATE_OFF;
                }

              //  ret = create_gpio_led(&led, &priv->leds[priv->num_leds++],
              //                        &pdev->dev, NULL);
              //  if (ret < 0) {
              //          of_node_put(child);
              //          goto err;
              //  }
	} */ 
		



		
		 

/*


    	for_each_child_of_node(np, child)
		
        if (!priv)
                return ERR_PTR(-ENOMEM);
*/
	return 0;
}
 


static int gpio_led_remove(struct platform_device *pdev)
{

	gpio_free(out_gpio1);
	gpio_free(out_gpio2);
	gpio_free(out_gpio3);
	kobject_put(led1_kobj);
	kobject_put(led2_kobj);
	kobject_put(led3_kobj);
	return 0;
}




static const struct of_device_id of_gpio_ledswitch_match[] = {
        { .compatible = "gpio-control-leds", },
        {},
};

static struct platform_driver gpio_ledswitch_driver = {
        .probe          = gpio_led_probe,
        .remove         = gpio_led_remove,
        .driver         = {
                .name   = "gpio_led_switch",
                .owner  = THIS_MODULE,
                .of_match_table = of_match_ptr(of_gpio_ledswitch_match),
        },
};

//module_platform_driver(gpio_ledswitch_driver);

static int __init hello_init(void)
{

	platform_driver_register(&gpio_ledswitch_driver);
	return 0;
}


static void  hello_exit(void)
{
		platform_driver_unregister(&gpio_ledswitch_driver);
}




module_init(hello_init);
module_exit(hello_exit);





MODULE_DESCRIPTION("GPIO LED SWITCH");
MODULE_LICENSE("GPL");


