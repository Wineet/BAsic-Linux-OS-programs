#include<unistd.h>
#include<sys/types.h>
#include<linux/fcntl.h>
#include<stdlib.h>
#include<stdio.h>
int main()
{

   int fdBar,fdBaz,fdFoo,ret,buf[1024];

   //this will setup an active file, for the process - ??
   //this active file will be different from a regular
   //active file of a regular file !!
   
   //this handle to an active file is used to 
   //access the actual system data exported 
   //by the procfs file/kernel module 
   
   //printf("Parent PID %d \n",getpid());
   
   fdFoo = open("/sys/kernel/kobject_example/foo",O_RDWR);
   
   if(fdFoo<0){
           perror("error in opening Foo");
           exit(1);
   }

   fdBaz = open("/sys/kernel/kobject_example/baz",O_RDWR);
   
   if(fdBaz<0){
           perror("error in opening Baz");
           exit(1);
   }

   fdBar = open("/sys/kernel/kobject_example/bar",O_RDWR);
   
   if(fdBar<0){
           perror("error in opening Bar");
           exit(1);
   }

 printf("value of fd is FdBar=%d,Baz=%d,Foo=%d\n", fdBar,fdBaz,fdFoo); 


  // exit(0); //just for testing open() 
 /*  lseek(fd,22,SEEK_SET);*/

/*  ret = read(fd,buf,30);
  printf("1..the no. characters returned is %d\n", ret);

  if(ret>0) { write(STDOUT_FILENO,buf,ret); }*/


 /* ret = read(fd,buf,13);
  printf("1..the no. characters returned is %d\n", ret);

  if(ret>0) { write(STDOUT_FILENO,buf,ret); }
*/


  /*ret = read(fd,buf,15);
   printf("2..the no. characters returned is %d\n", ret);
   

  if(ret>0) { write(STDOUT_FILENO,buf,ret); } */

  // ret = read(fd,buf,4096);*/
  // printf("1..the no. characters returned is %d\n", ret);

  //if(ret>0) { write(STDOUT_FILENO,buf,ret); }

  /* ret = read(fd,buf,2048);
   printf("1..the no. characters returned is %d\n", ret);

  if(ret>0) { write(STDOUT_FILENO,buf,ret); }
   ret = read(fd,buf,15);
   printf("the no. characters returned is %d\n", ret);

   if(ret>0) { write(STDOUT_FILENO,buf,ret); }*/
  
 //read() system call API returns +ve value, 
 //if there are bytes read into the user-space
 //buffer - if we pass a value to p3, read may 
 //copy lesser number of bytes and return a 
 //different size value, in ret - we must check 
 //this value, before further processing
 //
 //in addition, you may need to check for 
 //return value of 0, if there are no bytes
 //read() by the read() system call API- 
 //this normally happens, if there is no 
 //more data, in the active file, which can 
 //be a normal file or a procfs file 
 //
 //we may see a return value of -1, if there
 //is error, in access of the active - in the 
 //case of invalid fd or invalid access permissions 
 //
//Writing Dummy Data
	ret =  write(fdFoo,"1",4);
  	if(ret<0){
		printf("ERROR In write %d \n",ret);
	 }
 	printf("No of bytes written %d \n",ret);

	ret =  write(fdBaz,"hello",6);
  	if(ret<0){
		printf("ERROR In write %d \n",ret);
	 }
 	printf("No of bytes written %d \n",ret);
	
	ret =  write(fdBar,"a",1);
  	if(ret<0){
		printf("ERROR In write %d \n",ret);
	 }
 	printf("No of bytes written %d \n",ret);


/*
 fd = open("/sys/kernel/kobject_example/foo",O_RDONLY);*/
   lseek(fdFoo,0,SEEK_SET);
   ret = read(fdFoo,buf,1024);
   printf("No of bytes read %d\n",ret);
   if(ret<0) { perror("error in read"); exit(6); }
  
   if(ret>0) {
	  printf("Foo\n"); 
	   write(STDOUT_FILENO,buf,ret); }
  
   lseek(fdBaz,0,SEEK_SET);
   ret = read(fdBaz,buf,1024);
   printf("No of bytes read %d\n",ret);
   if(ret<0) { perror("error in read"); exit(6); }
   if(ret>0) { 
	  printf("Baz\n"); 
	   write(STDOUT_FILENO,buf,ret); } 
  
   lseek(fdBar,0,SEEK_SET);
   ret = read(fdBar,buf,1024);
   printf("No of bytes read %d\n",ret);
   if(ret<0) { perror("error in read"); exit(6); }
   if(ret>0) { 
	  printf("Bar\n"); 
	   write(STDOUT_FILENO,buf,ret); } 

   close(fdFoo);
   close(fdBaz);
   close(fdBar);
   exit(0);

}
