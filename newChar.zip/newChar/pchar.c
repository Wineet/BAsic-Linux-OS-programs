#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/version.h>
#include<linux/init.h>
#include<linux/device.h>
#include<linux/pci.h>
#include<linux/ioport.h>
#include<asm/unistd.h>
#include<linux/slab.h>
#include<linux/fs.h>
#include<linux/types.h>
#include<asm/uaccess.h>
#include<asm/io.h>
#include<linux/kdev_t.h>
#include<asm/fcntl.h>
#include<linux/sched.h>
#include<linux/wait.h>
#include<linux/errno.h>
#include<linux/kfifo.h>
#include<asm/irq.h>
#include<asm/errno.h>
#include<asm/ioctl.h>
#include<linux/string.h>
#include<linux/interrupt.h>
#include<linux/cdev.h>
//#include<include/stdlib.h>

#define MAX_BUFFSIZE (5*1024)

int ndevices =1;

static int __init mydrv_init(void);
static void __exit mydrv_exit(void);

static int mydrv_open(struct inode *inode, struct file *file);
static int mydrv_release(struct inode *inode, struct file *file);
static ssize_t mydrv_read(struct file *file, char __user *buf,
                                size_t count, loff_t *ppos);
static ssize_t mydrv_write(struct file *file, const char __user *buf,
                                size_t count, loff_t *ppos);

static dev_t devId;
static struct class *pseudo_class;

typedef struct priv_obj1
{
        struct list_head list;
        dev_t dev;   //device id of a specific device instance !!
        struct cdev cdev;
        unsigned char *buff;  //kernel buffer used with kfifo object
        //struct kfifo *kfifo;  //kfifo object ptr - older technique
        struct kfifo kfifo;  //kfifo object must be preallocated,
                             //in newer versions of the kernel- newer technique !!!
        spinlock_t my_lock;
        wait_queue_head_t queue; //you may need more than one wq
}C_DEV;


static struct file_operations dev_fops = {
        .open    = mydrv_open,
        .read    = mydrv_read,
        .write   = mydrv_write,
        .release = mydrv_release,
        .owner   = THIS_MODULE,
};

//LIST_HEAD(dev_list);

//OPEN
static int mydrv_open(struct inode *inode, struct file *file)
{
	C_DEV *dev;
        dev = container_of(inode->i_cdev,C_DEV,cdev);
        file->private_data = dev;
        dump_stack();
        //must complete open method - ???

        printk("Driver : open device\n");
	return 0;
}

//RELEASE
static int mydrv_release(struct inode *inode, struct file *file)
{
        dump_stack();

        printk("Driver : closed device\n");
	return 0;
}

//READ
static ssize_t mydrv_read(struct file *file, char __user *buf,
                               size_t count, loff_t *ppos)
{
	C_DEV *dev;
        int bytes;

	dev = file->private_data;
        printk("inside read call...\n");

        dump_stack();
	bytes = kfifo_len(&dev->kfifo);

	if(bytes==0)
        {
                if(file->f_flags & O_NONBLOCK) //if this active device file
                                               //is opened in non-blocking
                                               //mode
                {
                        return -EAGAIN;
                }
                else //for blocking mode of operation
               	{
		 wait_event_interruptible(dev->queue,
                 (kfifo_len(&dev->kfifo) != 0));
		}

	}
	//access_ok() validates user space buffer ptr and its locations
        //if it is a valid user-space buffer, return 1 - otherwise, 0 
        //such checks are must - otherwise, system space objects 
        //and buffers may be corrupted by user-space code, intentionally 
        //or unintentionally !!!
        if(access_ok(VERIFY_WRITE,(void __user*)buf,(unsigned long)count))
        {
                //a non blocking call, which returns no.of bytes 
                //successfully copied/read from the kfifo buffer !!!
                bytes = kfifo_out(&dev->kfifo,(unsigned char*)buf,count);
                //This function copies at most 'count' bytes from the FIFO into the 
		//'buff' and returns the number of copied bytes.
                return bytes;
                //return count;  //wrong
        }
        else
                return -EFAULT;

}

//WRITE
static ssize_t mydrv_write(struct file *file, const char __user *buf,
                                size_t count, loff_t *ppos)
{
	return 0;
}

C_DEV *my_drv=NULL;

static int __init mydrv_init(void)
{
	int ret; 	//status
	
	//Allocting Device Ids
	if(alloc_chrdev_region(&devId,0,ndevices,"pseudo_driver"))
	{
	        printk("Error in device creating.....\n");
                //err |= EBUSY;
                return -EBUSY;
        }

	//Succesfull Creation of Ids
	printk("Device Id %u\n",MAJOR(devId));

	my_drv = kmalloc(sizeof(C_DEV),GFP_KERNEL);

	if(my_drv == NULL)
	{
		printk("Cannot Allocate Memory \n");
		//exit(1);
	}
	
	printk("2\n");
	//Allocating Memory for Kernel Buffer
	my_drv->buff = kmalloc(MAX_BUFFSIZE,GFP_KERNEL);
	if(my_drv->buff == NULL)
        {
                printk("Cannot Allocate Memory to Buffer \n");
              //  exit(1);
        }
	
	//Initalize cdev
	cdev_init(&my_drv->cdev,&dev_fops);
	my_drv->cdev.owner = THIS_MODULE;
	
	printk("3\n");
	//Kfifo Initilization
	ret= kfifo_init(&my_drv->kfifo, my_drv->buff, MAX_BUFFSIZE);
        if (ret){
                printk("Kfifo_alloc ERROR");
	}

	//KObject
	kobject_set_name(&(my_drv->cdev.kobj),"pseudo_dev");
	
	printk("4\n");
	//Registartion of operations in cdev object
	my_drv->cdev.ops = &dev_fops;

		printk(" 5\n");
	//Linking device id with our cdev id
	if(cdev_add(&my_drv->cdev,devId,1))
	{
		printk(" CDEV HANDLER ERRROR\n");
		kobject_put(&(my_drv->cdev.kobj));
                unregister_chrdev_region(devId, 1);
                kfree(my_drv);
             //   goto error;

	}

		printk(" 6\n");
	//lock
	spin_lock_init(&(my_drv->my_lock));


	pseudo_class = class_create(THIS_MODULE, "pseudo_class454");
        if (IS_ERR(pseudo_class)) {

		printk(" CLASS ERROR HANDLER \n");
        	cdev_del(&my_drv->cdev);
        	unregister_chrdev_region(devId, 1);
		//ADD MORE ERROR HANDLIN
	   //	goto error;
        }
	printk("7\n");
        device_create(pseudo_class, NULL, devId,NULL,"pseudo_dev0");

/*	error:
        {
                //must complete error handling
                printk(KERN_ERR "cannot register device.\n");
                return -ENOMEM; //use a variable to set the error code
                                                //return the same variable from each point of error
        }*/

}

static void __exit mydrv_exit(void)
{
	cdev_del(&(my_drv->cdev));//remove the registration of the driver/device
        
	kfree(my_drv->buff);
        //kfifo_free(&my_drv->kfifo);        //Added


        //freeing the logical resources - device nos.
        unregister_chrdev_region(devId,1);
	device_destroy(pseudo_class, devId);
	class_destroy(pseudo_class);

        //freeing the system-space buffer

        kfree(my_drv);
        printk(KERN_INFO "plp_kmem: unloading.\n");

}

module_init(mydrv_init);
module_exit(mydrv_exit);


//module meta data
MODULE_DESCRIPTION("Demonstrate kernel memory allocation");

MODULE_ALIAS("memory_allocation");
MODULE_LICENSE("GPL");
MODULE_VERSION("0:1.0");



